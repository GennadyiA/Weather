package ru.geekbrains;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*
    Intent choosenCity = getIntent();
        String city = choosenCity.getStringExtra("city");
        TextView textView = findViewById(R.id.textView2);
        textView.setText(city);

            public void onClick(View view) {
        Intent intent = new Intent(MainFragment1.this, SettingsActivity.class);
        startActivity(intent);
    }
 */
    }


}